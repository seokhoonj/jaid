#' @title Desub
#'
#' @description
#' This function operates like `deparse(substitute(x))` inside the functions.
#'
#' @param x an expression that can be a string vector
#' @return a string vector
#'
#' @examples
#' # desub
#' \donttest{f1 <- function(a) desub(a)
#' f2 <- function(b) f1(b)
#' f3 <- function(c) f2(c)
#' f4 <- function(d) f3(d)
#' f5 <- function(e) f4(e)
#' desub(iris) # iris
#' f1(iris) # iris
#' f2(iris) # iris
#' f3(iris) # iris
#' f4(iris) # iris
#' f5(iris) # iris}
#'
#' # desubs
#' \donttest{f1 <- function(a) desubs(a)
#' f2 <- function(b) f1(b)
#' f3 <- function(c) f2(c)
#' f4 <- function(d) f3(d)
#' f5 <- function(e) f4(e)
#' desubs(c(iris, cars)) # "c" "iris" "cars"
#' f1(c(iris, cars)) # "c" "iris" "cars"
#' f2(c(iris, cars)) # "c" "iris" "cars"
#' f3(c(iris, cars)) # "c" "iris" "cars"
#' f4(c(iris, cars)) # "c" "iris" "cars"
#' f5(c(iris, cars)) # "c" "iris" "cars"}
#'
#' @export
desub <- function(x) {
  substitute(x) |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    eval(envir = parent.frame(n =  1)) |>
    eval(envir = parent.frame(n =  2)) |>
    eval(envir = parent.frame(n =  3)) |>
    eval(envir = parent.frame(n =  4)) |>
    eval(envir = parent.frame(n =  5)) |>
    eval(envir = parent.frame(n =  6)) |>
    eval(envir = parent.frame(n =  7)) |>
    eval(envir = parent.frame(n =  8)) |>
    eval(envir = parent.frame(n =  9)) |>
    eval(envir = parent.frame(n = 10)) |>
    eval(envir = parent.frame(n = 11)) |>
    eval(envir = parent.frame(n = 12)) |>
    eval(envir = parent.frame(n = 13)) |>
    deparse()
}

#' @rdname desub
#' @export
desubs <- function(x) {
  substitute(x) |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    substitute() |>
    eval(envir = parent.frame(n =  1)) |>
    eval(envir = parent.frame(n =  2)) |>
    eval(envir = parent.frame(n =  3)) |>
    eval(envir = parent.frame(n =  4)) |>
    eval(envir = parent.frame(n =  5)) |>
    eval(envir = parent.frame(n =  6)) |>
    eval(envir = parent.frame(n =  7)) |>
    eval(envir = parent.frame(n =  8)) |>
    eval(envir = parent.frame(n =  9)) |>
    eval(envir = parent.frame(n = 10)) |>
    eval(envir = parent.frame(n = 11)) |>
    eval(envir = parent.frame(n = 12)) |>
    eval(envir = parent.frame(n = 13)) |>
    vapply(FUN = deparse, FUN.VALUE = "character")
}

#' Assert class
#'
#' Assert object class.
#'
#' @param obj an object
#' @param class an object class
#' @return No return value
#'
#' @examples
#' # assert object class
#' \donttest{assert_class(cars, "data.frame")}
#'
#' @export
assert_class <- function(obj, class) {
  if (!inherits(obj, class)) {
    stop("Not an object of class: '",
         paste(class, collapse = ", "), "'",
         call. = FALSE)
  }
}
# assert_class <- function(obj, class) {
#   obj_name <- desub(obj)
#   if (!inherits(obj, class)) {
#     stop(obj_name, " is not an object of class: '",
#          paste(class, collapse = ", "), "'",
#          call. = FALSE)
#   }
# }

#' order numbers of columns
#'
#' Get order numbers of columns
#'
#' @param x a data.frame
#' @param cols string names of columns
#' @return order numbers of columns
#'
#' @examples
#' # order numbers of columns
#' icol(mtcars, c("disp", "drat", "qsec", "am", "carb"))
#'
#' @export
icol <- function(x, cols) {
  sapply(unique(cols), function(s) which(colnames(x) == s))
}

#' Match columns
#'
#' Get matched columns from a data frame.
#'
#' @param df a data frame
#' @param cols a string vector specifying columns
#' @return a string vector
#'
#' @examples
#' # match columns
#' \donttest{df <- data.frame(x = c(1, 2, 3), y = c("A", "B", "C"), z = c(4, 5, 6))
#' match_cols(df, c("x", "z"))}
#'
#' @export
match_cols <- function(df, cols) {
  assert_class(df, "data.frame")
  colnames(df)[match(cols, colnames(df), 0L)]
}

#' Find columns using regular expression pattern
#'
#' Find columns using regular expression pattern
#'
#' @param df a data.frame
#' @param pattern a string vector specifying columns
#' @return a string vector
#'
#' @examples
#' # find columns using regular expression pattern
#' \donttest{df <- data.frame(col_a = c(1, 2, 3), col_b = c("A", "B", "C"), col_c = c(4, 5, 6))
#' regex_cols(df, pattern = c("a|c"))}
#'
#' @export
regex_cols <- function(df, pattern) {
  assert_class(df, "data.frame")
  colnames(df)[grepl(pattern, names(df), perl = TRUE)]
}

#' Different columns
#'
#' Columns that the data frame does not contain
#'
#' @param df a data.frame
#' @param cols a string vector specifying columns
#' @return a string vector
#'
#' @examples
#' # different columns
#' \donttest{diff_cols(mtcars, c("mpg", "cyl", "disp", "hp", "drat"))}
#'
#' @export
diff_cols <- function(df, cols)
  setdiff(colnames(df), cols)

#' Validate columns
#'
#' Does the data frame contain all columns?
#'
#' @param df a data.frame
#' @param cols a string vector specifying columns
#' @return no return value
#'
#' @examples
#' # different columns
#' \dontrun{valid_cols(mtcars, c("mpg", "cyl", "disp", "hp", "drat"))}
#'
#' @export
valid_cols <- function(df, cols) {
  missing_cols <- setdiff(cols, colnames(df))
  if (length(missing_cols) > 0) {
    stop("The following columns are missing: ", paste(missing_cols, collapse = ", "))
  }
}

#' Check Column Specification Against a Data Frame
#'
#' Validates whether the columns in a given data frame match an expected
#' column specification. The specification includes expected column names
#' and their corresponding classes. The function returns a `data.table`
#' with the actual and expected classes, along with a status indicating
#' whether each column matches, is missing, or is extra.
#'
#' @param df A `data.frame` or `data.table` containing the data to be checked.
#' @param col_spec A named `list` defining the expected specification.
#'   Each name corresponds to a column, and each value is the expected class.
#'
#' @return A `data.table` with the following columns:
#'   \itemize{
#'     \item \code{column}: Column name
#'     \item \code{actual}: Actual class of the column (NA if missing)
#'     \item \code{expected}: Expected class of the column (NA if not specified)
#'     \item \code{status}: Comparison result: "match", "mismatch", "missing", or "extra"
#'   }
#'
#' @examples
#'
#' df <- data.frame(
#'   id = 1:3,
#'   name = c("Alice", "Bob", "Charlie"),
#'   age = c(25, 30, 28),
#'   paid = c(TRUE, FALSE, TRUE)
#' )
#'
#' col_spec <- list(
#'   id = "character",
#'   name = "character",
#'   age = "integer",
#'   premium = "numeric"
#' )
#'
#' check_col_spec(df, col_spec)
#'
#' @export
check_col_spec <- function(df, col_spec) {

  assert_class(df, "data.frame")

  if (!is.list(col_spec) || is.null(names(col_spec)) || any(names(col_spec) == ""))
    stop("col_spec must be a named list.")
  if (!all(sapply(col_spec, is.character)))
    stop("All elements of col_spec must be character strings (expected classes).")

  column <- status <- expected <- note <- NULL
  act_cols <- names(df)
  exp_cols <- names(col_spec)
  actual <- sapply(df, function(x) class(x)[1L])
  act_dt <- data.table::as.data.table(actual, keep.rownames = "column")
  exp_dt <- data.table::data.table(column = names(col_spec), expected = unlist(col_spec))
  dt <- data.table::rbindlist(
    list(
      act_dt[ exp_dt, on = .(column)],
      act_dt[!exp_dt, on = .(column)]
    ),
    fill = TRUE
  )
  dt[, status := data.table::fifelse(actual == expected, "match", "mismatch")]
  dt[is.na(actual), status := "missing"]
  dt[is.na(expected), status := "extra"]
  dt[, note := data.table::fifelse(
    status == "mismatch" & (
      (actual == "integer" & expected == "numeric") |
      (actual == "numeric" & expected == "integer")
    ), "compatible", NA_character_
  )]

  # --- Column Check Summary ---
  if (requireNamespace("cli", quietly = TRUE)) {
    cli::cli_h2("Column Check Summary")
    for (stat in c("match", "mismatch", "missing", "extra")) {
      dt_sub <- dt[status == stat]
      if (nrow(dt_sub) == 0) {
        msg_str <- ""
      } else if (stat == "mismatch") {
        msg_vec <- dt_sub[, paste0(
          column, " (", actual, " \u2192 ", expected,
          ifelse(!is.na(note), paste0(": ", note), ""), ")"
        )]
        msg_str <- paste(msg_vec, collapse = ", ")
      } else {
        msg_str <- paste(dt_sub$column, collapse = ", ")
      }

      color_msg <- switch(stat,
                          match    = cli::col_green(msg_str),
                          mismatch = cli::col_red(msg_str),
                          missing  = cli::col_yellow(msg_str),
                          extra    = cli::col_cyan(msg_str)
      )
      icon <- switch(stat, match = "o", mismatch = "x", missing = "-", extra = "+")
      cli::cli_alert("{.strong {icon} {stat}:} {color_msg}")
    }
    cli::cli_text("")
  }
  data.table::setindex(dt, NULL)
  return(dt)
}

#' Has rows
#'
#' Whether the data has rows
#'
#' @param df a data.frame
#' @param error_raise a logcial whether to raise an error or not
#' @return a logical value
#'
#' @examples
#' # has rows
#' \dontrun{
#' df <- data.frame()
#' has_rows(df)}
#'
#' # raise an error
#' \dontrun{
#' df <- data.frame()
#' has_rows(df, error_raise = TRUE)}
#'
#' @export
has_rows <- function(df, error_raise = FALSE) {
  assert_class(df, "data.frame")
  # df_name <- desub(df)
  nrows <- nrow(df)
  rt <- nrows != 0
  if (!error_raise)
    return(rt)
  if (!rt) {
    # stop("'", df_name, "' doesn't have row(s): ",
    #      call. = FALSE)
    stop("No rows", call. = FALSE)
  }
}

#' Has columns
#'
#' Whether the data has specific columns
#'
#' @param df a data.frame
#' @param cols column names
#' @param error_raise a logical whether to raise an error or not
#' @return a logical value
#'
#' @examples
#' # has columns
#' \donttest{has_cols(mtcars, c("cyl", "disp"))}
#'
#' # raise an error
#' \dontrun{
#' has_cols(mtcars, c("cyl", "iris"), error_raise = TRUE)}
#'
#' @export
has_cols <- function(df, cols, error_raise = FALSE) {
  assert_class(df, "data.frame")
  df_name <- desub(df)
  df_cols <- colnames(df)
  diff_cols <- setdiff(cols, df_cols)
  rt <- length(diff_cols) == 0
  if (!error_raise)
    return(rt)
  if (!rt) {
    # stop("'", df_name, "' doesn't have column(s): ",
    #      paste0(diff_cols, collapse = ", "), ".",
    #      call. = FALSE)
    stop("No columns: ",
         paste0(diff_cols, collapse = ", "), ".",
         call. = FALSE)
  }
}

#' Has a length
#'
#' Whether the object has a length or not
#'
#' @param x a
#' @param error_raise a logical whether to raise an error or not
#' @return a logical value
#'
#' @examples
#' # has a length
#' \donttest{has_len(c(numeric(), character()))}
#'
#' # raise an error
#' \dontrun{
#' has_len(c(numeric(), character()), error_raise = TRUE)}
#'
#' @export
has_len <- function(x, error_raise = FALSE) {
  assert_class(x, c("character", "integer", "numeric", "Date", "POSIXt"))
  # x_name <- desub(x)
  rt <- rlang::has_length(x)
  if (!error_raise)
    return(rt)
  if (!rt)
    # stop("'", x_name, "' doesn't have a length.", call. = FALSE)
    stop("No length.", call. = FALSE)
}

#' Change columns from uppercase to lowercase or from lowercase to uppercase
#'
#' Change columns from uppercase to lowercase or from lowercase to uppercase
#'
#' @param df a data.frame
#' @return no return values
#'
#' @examples
#' # Change columns case
#' \donttest{df <- mtcars
#' set_col_upper(df)
#' set_col_lower(df)}
#'
#' @export
set_col_lower <- function(df)
  data.table::setnames(df, colnames(df), tolower(colnames(df)))

#' @rdname set_col_lower
#' @export
set_col_upper <- function(df)
  data.table::setnames(df, colnames(df), toupper(colnames(df)))

#' Fast column reordering of data.table by reference
#'
#' set_col_order reorders the columns of data.table, by reference, to the new order provided.
#'
#' @param df a data.table
#' @param neworder names of columns of the new column name ordering
#' @param before,after If one of them (not both) was provided with a column name or number, neworder will be inserted before or after that column.
#' @return no return value
#'
#' @examples
#' \dontrun{
#' # set_col_order
#' df <- mtcars
#' set_col_order(df, .(gear, carb), after = mpg)
#' set_col_order(df, .(gear, carb), after = am)}
#'
#' @export
set_col_order <- function(df, neworder, before = NULL, after = NULL) {
  neworder <- match_cols(df, sapply(rlang::enexpr(neworder), rlang::as_name))
  before <- match_cols(df, sapply(rlang::enexpr(before), rlang::as_name))
  after  <- match_cols(df, sapply(rlang::enexpr(after), rlang::as_name))
  if (!has_len(before)) before <- NULL
  if (!has_len(after)) after <- NULL
  data.table::setcolorder(x = df, neworder = neworder, before = before, after = after)
}

#' Set labels
#'
#' Set column labels for a data frame.
#'
#' @param df a data.frame
#' @param labels a string vector specifying labels to describe columns
#' @param cols a string vector specifying columns
#'
#' @examples
#' # set labels
#' \dontrun{df <- data.frame(Q1 = c(0, 1, 1), Q2 = c(1, 0, 1))
#' set_labels(df, labels = c("Rainy?", "Umbrella?"))
#' View(df)}
#'
#' @export
set_labels <- function(df, labels, cols) {
  if (missing(cols))
    cols <- names(df)
  if (length(cols) != length(labels))
    stop("the length of columns and the length of labels are different.")
  lapply(seq_along(cols),
         function(x) data.table::setattr(df[[cols[[x]]]], "label", labels[[x]]))
  invisible(df)
}

#' @rdname set_labels
#' @export
get_labels <- function(df, cols) {
  if (missing(cols))
    cols <- names(df)
  sapply(cols, function(x) attr(df[[x]], "label"), USE.NAMES = FALSE)
}

#' Get a copied data.table
#'
#' Get a copied data.table.
#'
#' @param df a data.frame
#' @return a copied data.table
#'
#' @examples
#' # get copied data.table
#' \donttest{df <- data.frame(x = 1:3, y = c("a", "b", "c"))
#' get_copied_dt(df)}
#'
#' @export
get_copied_dt <- function(df)
  return(data.table::setDT(data.table::copy(df))[])

#' Set data.table function
#'
#' setDT function re-exported from `data.table`.
#'
#' @param df a data.frame
#' @return no return values.
#'
#' @seealso [data.table::setDT()]
#'
#' @export
set_dt <- function(df) {
  assert_class(df, "data.frame")
  if (!has_ptr(df)) {
    n <- sys.nframe()
    df_name <- desub(df)
    old_class <- class(df)
    data.table::setDT(df)
    assign(df_name, df, envir = parent.frame(n))
    invisible()
  }
  if (!inherits(df, "data.table")) {
    data.table::setattr(df, "class", c("data.table", "data.frame"))
  }
}

#' Set tibble function
#'
#' as_tibble function re-exported from `tibble`.
#'
#' @param df a data.frame
#' @return no return values.
#'
#' @seealso [tibble::as_tibble()]
#'
#' @export
set_tibble <- function(df) {
  assert_class(df, "data.frame")
  if (!has_ptr(df)) {
    n <- sys.nframe()
    df_name <- desub(df)
    old_class <- class(df)
    data.table::setDT(df)
    data.table::setattr(df, "class", c("tbl_df", "tbl", "data.frame"))
    assign(df_name, df, envir = parent.frame(n))
    invisible()
  }
  if (!inherits(df, "tbl_df")) {
    data.table::setattr(df, "class", c("tbl_df", "tbl", "data.frame"))
  }
}

#' Equal columns of two data frames.
#'
#' Whether the columns of two data frames are equal.
#'
#' @param x,y two data frames
#' @return a logical vector
#'
#' @examples
#' # Are the columns of two data frames equal?
#' \donttest{equal(mtcars, mtcars)}
#'
#' @export
equal <- function(x, y) {
  assert_class(x, "data.frame")
  assert_class(y, "data.frame")
  x_name <- deparse(substitute(x))
  y_name <- deparse(substitute(y))
  x_cols <- colnames(x); x_nrow <- nrow(x); x_ncol <- ncol(x)
  y_cols <- colnames(y); y_nrow <- nrow(y); y_ncol <- ncol(y)
  if (length(x_cols) != length(y_cols)) {
    stop(sprintf("different number of cols. (%s: %s, %s: %s)",
                 x_name, x_ncol, y_name, y_ncol))
  } else {
    if (any(sort(x_cols) != sort(y_cols))) {
      stop(sprintf("different column names.\n%s: %s\n%s: %s",
                   x_name, paste(x_cols, collapse = ", "),
                   y_name, paste(y_cols, collapse = ", ")))
    }
  }
  if (x_nrow != y_nrow)
    stop(sprintf("different number of rows. (%s: %s, %s: %s).",
                 x_name, x_nrow, y_name, y_nrow))
  return(sapply(x_cols, function(s) all(x[[s]] == y[[s]])))
}


#' As comma applied label
#'
#' Convert a numeric vector to a comma applied string vector.
#'
#' @param x a numeric vector
#' @return a string vector
#'
#' @examples
#' # convert to a comma applied string vector
#' \donttest{as_comma(c(123456, 234567))}
#'
#' @export
as_comma <- function(x) {
  assert_class(x, c("integer", "numeric"))
  format(round(x), big.mark = ",")
}

#' Paste comma
#'
#' Paste vector elements with commas.
#'
#' @param x a vector
#' @param newline a logical whether to add newlines by each element
#'
#' @examples
#' # paste comma
#' \donttest{paste_comma(names(mtcars))}
#'
#' @export
paste_comma <- function(x, newline = FALSE) {
  if (newline) {
    cat(paste0("c(", paste0("\"", paste(x, collapse = "\"\n, \""), "\""), "\n)"))
  }
  else {
    cat(paste0("c(", paste0("\"", paste(x, collapse = "\", \""), "\""), ")"))
  }
}

#' Quote and paste comma
#'
#' Quote vector elements and paste it with commas.
#'
#' @param ... an expressions with no quotations
#' @param newline a logical whether to add newlines by each element
#'
#' @examples
#' # quote comma
#' \donttest{quote_comma(mpg, cyl, disp, hp, drat)}
#'
#' @export
quote_comma <- function(..., newline = FALSE) {
  if (newline) {
    cat(paste0("c(", paste0("\"", paste(vapply(substitute(list(...)),
                                  deparse, "character")[-1L], collapse = "\"\n, \""),
               "\""), "\n)"))
  }
  else {
    cat(paste0("c(", paste0("\"", paste(vapply(substitute(list(...)),
                                  deparse, "character")[-1L], collapse = "\", \""),
               "\""), ")"))
  }
  cat("\n")
}

#' Integer64 to numeric
#'
#' Change class from `integer64` to `numeric` for a `data.frame`
#'
#' @param df a `data.frame`
#'
#' @export
i64_to_num <- function(df) {
  cols <- jaid::type(df)[class == "integer64"]$column
  df[, (cols) := lapply(.SD, as.numeric), .SDcols = cols]
  return(df)
}

# to be updated -----------------------------------------------------------

sort_group_by <- function(x) {
  .Call(SortGroupBy, x)
}

join <- function(..., by, all = FALSE, all.x = all, all.y = all, sort = TRUE) {
  Reduce(function(...) merge(..., by = by, all = all, all.x = all.x,
                             all.y = all.y, sort = sort), list(...))
}
