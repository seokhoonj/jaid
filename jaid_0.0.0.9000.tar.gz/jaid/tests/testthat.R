# This file is part of the standard setup for testthat.
# It is recommended that you do not modify it.
#
# Where should you do additional test configuration?
# Learn more about the roles of various files in:
# * https://r-pkgs.org/tests.html
# * https://testthat.r-lib.org/reference/test_package.html#special-files

# library(testthat)
# library(jaid)
#
# test_check("jaid")

# devtools::document()
# cohort <- loadRDS("~/Dropbox/shiny-vuw/data/cohort/cohort_A.rds")
#
# microbenchmark::microbenchmark(
#   # sapply(cohort[1:10000000], function(x) fastMode(x)[[1L]]),
#   sapply(cohort[1:10000000], mostfreq),
#   times = 1
# )


# rm(df)
# f(df)
# attr(df, ".internal.selfref")
#
# f1 <- function(x) {
#   x <- rlang::enexpr(x)
#   f(!!x)
# }
#
# f1(df)
#
# df
# sys.nframe()
# f()
# parent.frame()
#
# identical(environment(), globalenv())

# df
# set_dt2 <- function(x) {
#   assert_class(x, "data.frame")
#   if (!inherits(x, "data.table")) {
#     if (!has_ptr(x, error_raise = FALSE)) {
#       n <- sys.nframe()
#       x_name <- desub(x)
#       old_class <- class(x)
#       data.table::setDT(x)
#       assign(x_name, x, envir = parent.frame(n))
#       assign(x_name, x, envir = parent.frame(n-1))
#     }
#     else {
#       set_attr(x, "class", c("data.table", "data.frame"))
#     }
#   }
# }
#
# f <- function(x) {
#   x_name <- desub(x)
#   old_class <- class(df)
#   set_dt2(df)
#   print(data.table::address(df))
#   dt <- jaid::combine_overlapping_date_range(df, id, work, sdate, edate)
#   set_attr(dt, "class", old_class)
#   set_attr(df, "class", old_class)
#   print(data.table::address(df))
#   return(dt)
# }
# f1 <- function(y) {
#   f(y)
# }
# f2 <- function(z) {
#   f(z)
# }
#
# f1(df)
#
# f2(df)
# setDF(df)
# attributes(df)
# rm(df)
#
# print(data.table::address(df))
# f2(df)
#
# attributes(df)
